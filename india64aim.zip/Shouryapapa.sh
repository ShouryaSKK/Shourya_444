rm -rf /data/data/com.tencent.ig/files &> /dev/null
rm -rf /data/data/com.tencent.ig/app_crashrecord &> /dev/null
echo "@SHOURYA_4" > /data/data/com.tencent.ig/files
echo "@SHOURYA_4" > /data/data/com.tencent.ig/app_crashrecord
chmod 000 /data/data/com.tencent.ig/files
chmod 000 /data/data/com.tencent.ig/app_crashrecord
rm -rf /data/data/com.tencent.ig/files &> /dev/null
rm -rf /data/data/com.tencent.ig/app_crashrecord &> /dev/null
echo "FUCK COPY PASTERS" > /data/data/com.tencent.ig/files
echo "JOIN TELEGRAM @SHOURYA_YT" > /data/data/com.tencent.ig/app_crashrecord
chmod 000 /data/data/com.tencent.ig/files
chmod 000 /data/data/com.tencent.ig/app_crashrecord
echo "Crash Fix Done" 

rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/core_patch*

rm -rf /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks/game_patch*

chmod 555 /data/media/0/Android/data/com.tencent.ig/files/UE4Game/ShadowTrackerExtra/ShadowTrackerExtra/Saved/Paks

echo "DONE"
echo " JOIN @SHOURYA_4 "